import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { ToastProvider } from '@/components/Toast';
import SuperAdminDashboard from '@/components/SuperAdminDashboard';
import VendorDashboard from '@/components/VendorDashboard';
import CaptivePortal from '@/components/CaptivePortal';
import type { Tenant, Role } from '@/lib/types';
import {
  ShieldCheck, Building2, Smartphone, Router, Activity,
  DollarSign, Wifi, Users, Zap, ChevronDown, Radio,
  TrendingUp, Server,
} from 'lucide-react';

function AppContent() {
  const [role, setRole] = useState<Role>('superadmin');
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [selectedTenantId, setSelectedTenantId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [vendorNav, setVendorNav] = useState<'dashboard' | 'portal'>('dashboard');

  const fetchTenants = useCallback(async () => {
    const { data } = await supabase.from('tenants').select('*').order('created_at', { ascending: true });
    const t = (data || []) as Tenant[];
    setTenants(t);
    if (t.length > 0 && !selectedTenantId) {
      setSelectedTenantId(t[0].id);
    }
    setLoading(false);
  }, [selectedTenantId]);

  useEffect(() => { fetchTenants(); }, [fetchTenants]);

  const selectedTenant = tenants.find((t) => t.id === selectedTenantId) || tenants[0] || null;

  const navItems = [
    { id: 'superadmin' as Role, label: 'SuperAdmin', icon: ShieldCheck, desc: 'Platform Owner' },
    { id: 'vendor' as Role, label: 'Vendor', icon: Building2, desc: 'Hotspot Owner' },
    { id: 'enduser' as Role, label: 'End-User', icon: Smartphone, desc: 'Captive Portal' },
  ];

  const vendorNavItems = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: Activity },
    { id: 'portal' as const, label: 'Portal Preview', icon: Smartphone },
  ];

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-zinc-950">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 animate-spin rounded-full border-2 border-white/20 border-t-indigo-500" />
          <p className="text-sm text-zinc-500">Loading NetPulse SaaS...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-zinc-950 text-white overflow-hidden">
      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-white/10 bg-zinc-950/95 backdrop-blur-xl transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        {/* Logo */}
        <div className="flex items-center gap-3 border-b border-white/10 px-6 py-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-emerald-500">
            <Radio className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white leading-tight">NetPulse</h1>
            <p className="text-[10px] font-medium uppercase tracking-wider text-zinc-500">SaaS Platform</p>
          </div>
        </div>

        {/* Role Switcher */}
        <div className="border-b border-white/10 px-4 py-4">
          <p className="mb-2 px-2 text-[10px] font-semibold uppercase tracking-wider text-zinc-600">Role Switcher</p>
          <div className="space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => { setRole(item.id); setSidebarOpen(false); setVendorNav('dashboard'); }}
                className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 transition-colors ${
                  role === item.id ? 'bg-white/10 text-white' : 'text-zinc-500 hover:bg-white/5 hover:text-zinc-300'
                }`}
              >
                <item.icon className="h-4 w-4" />
                <div className="text-left">
                  <p className="text-sm font-medium">{item.label}</p>
                  <p className="text-[10px] text-zinc-600">{item.desc}</p>
                </div>
                {role === item.id && <div className="ml-auto h-1.5 w-1.5 rounded-full bg-indigo-400" />}
              </button>
            ))}
          </div>
        </div>

        {/* Vendor selector (shown for vendor & enduser roles) */}
        {(role === 'vendor' || role === 'enduser') && (
          <div className="border-b border-white/10 px-4 py-4">
            <p className="mb-2 px-2 text-[10px] font-semibold uppercase tracking-wider text-zinc-600">Active Vendor</p>
            <div className="relative">
              <select
                value={selectedTenantId}
                onChange={(e) => setSelectedTenantId(e.target.value)}
                className="w-full appearance-none rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 pr-8 text-sm text-white focus:border-indigo-500/50 focus:outline-none"
              >
                {tenants.map((t) => (
                  <option key={t.id} value={t.id} className="bg-zinc-900">{t.business_name}</option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
            </div>
          </div>
        )}

        {/* Vendor sub-nav */}
        {role === 'vendor' && selectedTenant && (
          <div className="border-b border-white/10 px-4 py-4">
            <p className="mb-2 px-2 text-[10px] font-semibold uppercase tracking-wider text-zinc-600">Vendor Views</p>
            <div className="space-y-1">
              {vendorNavItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setVendorNav(item.id)}
                  className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${
                    vendorNav === item.id ? 'bg-white/10 text-white' : 'text-zinc-500 hover:bg-white/5 hover:text-zinc-300'
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Status footer */}
        <div className="mt-auto border-t border-white/10 px-4 py-4">
          <div className="flex items-center gap-2 rounded-xl border border-emerald-500/20 bg-emerald-500/5 px-3 py-2.5">
            <div className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-medium text-emerald-300">All Systems Operational</span>
          </div>
          <p className="mt-2 px-2 text-[10px] text-zinc-600">NetPulse SaaS v1.0 · Demo Mode</p>
        </div>
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center justify-between border-b border-white/10 px-6 py-3.5">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="rounded-lg border border-white/10 p-2 text-zinc-400 hover:bg-white/5 lg:hidden"
            >
              <Radio className="h-4 w-4" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-semibold text-white">
                  {role === 'superadmin' ? 'Platform Command Center' :
                   role === 'vendor' ? (vendorNav === 'portal' ? 'Captive Portal Preview' : 'Vendor Dashboard') :
                   'End-User Captive Portal'}
                </h2>
                <span className="rounded-md bg-indigo-500/10 px-2 py-0.5 text-[10px] font-medium text-indigo-300 capitalize">
                  {role === 'superadmin' ? 'SuperAdmin' : role === 'vendor' ? 'Vendor' : 'End-User'}
                </span>
              </div>
              <p className="text-xs text-zinc-500">
                {role === 'superadmin' ? 'Monitoring all vendors across the platform' :
                 role === 'vendor' && selectedTenant ? selectedTenant.business_name :
                 role === 'enduser' && selectedTenant ? `Previewing: ${selectedTenant.business_name}` : ''}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {role === 'superadmin' && (
              <div className="hidden items-center gap-4 sm:flex">
                <div className="flex items-center gap-1.5 text-xs text-zinc-500">
                  <Server className="h-3.5 w-3.5" /> 12 Routers
                </div>
                <div className="flex items-center gap-1.5 text-xs text-zinc-500">
                  <Building2 className="h-3.5 w-3.5" /> {tenants.length} Vendors
                </div>
                <div className="flex items-center gap-1.5 text-xs text-emerald-400">
                  <div className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" /> Live
                </div>
              </div>
            )}
            <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-1.5">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 to-emerald-500 text-xs font-bold text-white">
                {role === 'superadmin' ? 'SA' : role === 'vendor' ? 'V' : 'U'}
              </div>
              <span className="text-xs font-medium text-white capitalize">
                {role === 'superadmin' ? 'SuperAdmin' : role === 'vendor' ? 'Vendor' : 'End-User'}
              </span>
            </div>
          </div>
        </header>

        {/* Dashboard content */}
        <main className="flex-1 overflow-y-auto p-6">
          {role === 'superadmin' && <SuperAdminDashboard />}
          {role === 'vendor' && selectedTenant && vendorNav === 'dashboard' && (
            <VendorDashboard tenant={selectedTenant} onBrandingChange={fetchTenants} />
          )}
          {role === 'vendor' && selectedTenant && vendorNav === 'portal' && (
            <CaptivePortal tenant={selectedTenant} />
          )}
          {role === 'enduser' && selectedTenant && (
            <CaptivePortal tenant={selectedTenant} />
          )}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AppContent />
    </ToastProvider>
  );
}
