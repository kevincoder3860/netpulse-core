import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/Toast';
import Modal from '@/components/Modal';
import MetricCard from '@/components/MetricCard';
import StatusBadge from '@/components/StatusBadge';
import {
  formatCurrency, formatNumber, formatDuration, formatSpeed,
  timeAgo, formatDateTime, generateMacAddress, generateSecret,
} from '@/lib/utils';
import type { Tenant, Nas, HotspotPlan, Transaction } from '@/lib/types';
import {
  DollarSign, Wallet, Users, Router, Plus, Wifi, Clock,
  Gauge, Smartphone, Copy, Check, Palette, Image as ImageIcon,
  FileText, Upload, Zap, ArrowUpRight, ArrowDownRight, Activity,
  TrendingUp,
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line,
} from 'recharts';

interface VendorDashboardProps {
  tenant: Tenant;
  onBrandingChange: () => void;
}

export default function VendorDashboard({ tenant, onBrandingChange }: VendorDashboardProps) {
  const { toast } = useToast();
  const [routers, setRouters] = useState<Nas[]>([]);
  const [plans, setPlans] = useState<HotspotPlan[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'routers' | 'plans' | 'transactions' | 'branding'>('overview');

  const [showRouterModal, setShowRouterModal] = useState(false);
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [editingPlan, setEditingPlan] = useState<HotspotPlan | null>(null);
  const [copiedScript, setCopiedScript] = useState(false);

  const [newRouter, setNewRouter] = useState({ nasname: '', shortname: '', nas_ip: '' });
  const [generatedMac, setGeneratedMac] = useState('');
  const [generatedSecret, setGeneratedSecret] = useState('');

  const [planForm, setPlanForm] = useState({
    name: '', price: '', duration_minutes: '60', max_download_kbps: '5120',
    max_upload_kbps: '2048', max_devices: '1',
  });

  const [branding, setBranding] = useState({
    logo_url: tenant.logo_url,
    brand_color: tenant.brand_color,
    welcome_headline: tenant.welcome_headline,
    terms_of_service: tenant.terms_of_service,
  });
  const [savingBranding, setSavingBranding] = useState(false);

  const fetchData = useCallback(async () => {
    const [nRes, pRes, txRes] = await Promise.all([
      supabase.from('nas').select('*').eq('tenant_id', tenant.id).order('created_at', { ascending: false }),
      supabase.from('hotspot_plans').select('*').eq('tenant_id', tenant.id).order('created_at', { ascending: false }),
      supabase.from('transactions').select('*').eq('tenant_id', tenant.id).order('created_at', { ascending: false }),
    ]);
    setRouters((nRes.data || []) as Nas[]);
    setPlans((pRes.data || []) as HotspotPlan[]);
    setTransactions((txRes.data || []) as Transaction[]);
    setLoading(false);
  }, [tenant.id]);

  useEffect(() => { fetchData(); }, [fetchData]);

  useEffect(() => {
    setBranding({
      logo_url: tenant.logo_url,
      brand_color: tenant.brand_color,
      welcome_headline: tenant.welcome_headline,
      terms_of_service: tenant.terms_of_service,
    });
  }, [tenant]);

  const todayTx = transactions.filter((t) => {
    const d = new Date(t.created_at); const now = new Date();
    return d.getDate() === now.getDate() && d.getMonth() === now.getMonth();
  });
  const dailyGross = todayTx.reduce((s, t) => s + Number(t.gross_amount), 0);
  const monthlyGross = transactions.filter((t) => {
    const d = new Date(t.created_at); const now = new Date();
    return d.getMonth() === now.getMonth();
  }).reduce((s, t) => s + Number(t.gross_amount), 0);
  const netEarnings = transactions.reduce((s, t) => s + Number(t.vendor_net_amount), 0);
  const onlineRouters = routers.filter((r) => r.is_online).length;
  const activeUsers = transactions.filter((t) => {
    return new Date(t.created_at).getTime() > Date.now() - 3600000;
  }).length;

  const revenueTrend = Array.from({ length: 14 }, (_, i) => {
    const date = new Date(); date.setDate(date.getDate() - (13 - i));
    const dayStr = date.toISOString().slice(0, 10);
    return {
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      revenue: transactions.filter((t) => t.created_at.slice(0, 10) === dayStr).reduce((s, t) => s + Number(t.gross_amount), 0),
    };
  });

  const bandwidthData = Array.from({ length: 12 }, (_, i) => ({
    time: `${i * 2}:00`,
    download: Math.floor(Math.random() * 40 + 30),
    upload: Math.floor(Math.random() * 20 + 10),
  }));

  const handleAddRouter = async () => {
    if (!newRouter.nasname || !newRouter.shortname) {
      toast('Please fill in router name and location', 'error');
      return;
    }
    const mac = generatedMac || generateMacAddress();
    const secret = generatedSecret || generateSecret();
    const { error } = await supabase.from('nas').insert({
      tenant_id: tenant.id,
      nasname: newRouter.nasname,
      shortname: newRouter.shortname,
      nas_ip: newRouter.nas_ip || '10.0.0.1',
      mac_address: mac,
      secret,
      type: 'mikrotik',
      is_online: true,
    });
    if (error) { toast('Failed to add router', 'error'); return; }
    await supabase.from('system_events').insert({
      tenant_id: tenant.id, event_type: 'router', severity: 'success',
      message: `Router ${newRouter.nasname} (${newRouter.shortname}) added to fleet`,
    });
    toast(`Router "${newRouter.nasname}" added to fleet`);
    setNewRouter({ nasname: '', shortname: '', nas_ip: '' });
    setGeneratedMac(''); setGeneratedSecret('');
    setShowRouterModal(false);
    fetchData();
  };

  const mikrotikScript = (r: typeof newRouter, mac: string, secret: string) => `/radius add service=hotspot address=10.0.0.1 secret=${secret}
/radius add service=hotspot address=10.0.0.1 secret=${secret}
/ip hotspot profile set hsprof1 hotspot-address=10.0.0.1 use-radius=yes
/ip hotspot user profile set [find name=default] shared-users=1
/system identity set name=${r.nasname || 'MT-NEW'}
# MAC: ${mac}
# NAS IP: ${r.nas_ip || '10.0.0.1'}
# Location: ${r.shortname || 'New Location'}
# Generated by NetPulse SaaS`;

  const copyScript = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedScript(true);
    toast('MikroTik script copied to clipboard');
    setTimeout(() => setCopiedScript(false), 2000);
  };

  const handleSavePlan = async () => {
    if (!planForm.name || !planForm.price) {
      toast('Please fill in plan name and price', 'error');
      return;
    }
    const payload = {
      tenant_id: tenant.id,
      name: planForm.name,
      price: parseFloat(planForm.price),
      duration_minutes: parseInt(planForm.duration_minutes) || 60,
      max_download_kbps: parseInt(planForm.max_download_kbps) || 5120,
      max_upload_kbps: parseInt(planForm.max_upload_kbps) || 2048,
      max_devices: parseInt(planForm.max_devices) || 1,
      is_active: true,
    };
    if (editingPlan) {
      const { error } = await supabase.from('hotspot_plans').update(payload).eq('id', editingPlan.id);
      if (error) { toast('Failed to update plan', 'error'); return; }
      toast(`Plan "${planForm.name}" updated`);
    } else {
      const { error } = await supabase.from('hotspot_plans').insert(payload);
      if (error) { toast('Failed to create plan', 'error'); return; }
      toast(`Plan "${planForm.name}" created`);
    }
    setShowPlanModal(false);
    setEditingPlan(null);
    setPlanForm({ name: '', price: '', duration_minutes: '60', max_download_kbps: '5120', max_upload_kbps: '2048', max_devices: '1' });
    fetchData();
  };

  const openEditPlan = (plan: HotspotPlan) => {
    setEditingPlan(plan);
    setPlanForm({
      name: plan.name, price: String(plan.price), duration_minutes: String(plan.duration_minutes),
      max_download_kbps: String(plan.max_download_kbps), max_upload_kbps: String(plan.max_upload_kbps),
      max_devices: String(plan.max_devices),
    });
    setShowPlanModal(true);
  };

  const togglePlanActive = async (plan: HotspotPlan) => {
    await supabase.from('hotspot_plans').update({ is_active: !plan.is_active }).eq('id', plan.id);
    toast(`Plan "${plan.name}" ${plan.is_active ? 'deactivated' : 'activated'}`);
    fetchData();
  };

  const handleSaveBranding = async () => {
    setSavingBranding(true);
    const { error } = await supabase.from('tenants').update({
      logo_url: branding.logo_url,
      brand_color: branding.brand_color,
      welcome_headline: branding.welcome_headline,
      terms_of_service: branding.terms_of_service,
    }).eq('id', tenant.id);
    if (error) { toast('Failed to save branding', 'error'); setSavingBranding(false); return; }
    toast('Portal branding updated successfully');
    setSavingBranding(false);
    onBrandingChange();
  };

  const planNameById = (id: string | null) => plans.find((p) => p.id === id)?.name || '—';
  const nasNameById = (id: string | null) => routers.find((r) => r.id === id)?.nasname || '—';

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-indigo-500" />
      </div>
    );
  }

  const tabs = [
    { id: 'overview' as const, label: 'Overview', icon: Activity },
    { id: 'routers' as const, label: 'Router Fleet', icon: Router },
    { id: 'plans' as const, label: 'Hotspot Plans', icon: Wifi },
    { id: 'transactions' as const, label: 'Transactions', icon: DollarSign },
    { id: 'branding' as const, label: 'Portal Branding', icon: Palette },
  ];

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex flex-wrap gap-1 rounded-xl border border-white/10 bg-white/[0.02] p-1">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
              activeTab === t.id ? 'bg-white/10 text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <t.icon className="h-4 w-4" />
            {t.label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <MetricCard label="Daily Gross Revenue" value={formatCurrency(dailyGross)} icon={<DollarSign className="h-5 w-5" />} accent="indigo" trend={`${todayTx.length} sales today`} trendUp />
            <MetricCard label="Monthly Gross" value={formatCurrency(monthlyGross)} icon={<Wallet className="h-5 w-5" />} accent="emerald" trend="+15.3% MoM" trendUp />
            <MetricCard label="Net Earnings" value={formatCurrency(netEarnings)} icon={<TrendingUp className="h-5 w-5" />} accent="amber" />
            <MetricCard label="Active Hotspot Users" value={formatNumber(activeUsers)} icon={<Users className="h-5 w-5" />} accent="sky" />
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <div className="glass-card rounded-2xl p-5 lg:col-span-2">
              <h3 className="mb-4 text-sm font-semibold text-white">Revenue Trend</h3>
              <ResponsiveContainer width="100%" height={240}>
                <AreaChart data={revenueTrend}>
                  <defs>
                    <linearGradient id="vRev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="date" tick={{ fill: '#71717a', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#71717a', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#18181b', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', fontSize: '12px' }} formatter={(v: number) => formatCurrency(v)} />
                  <Area type="monotone" dataKey="revenue" stroke="#6366f1" strokeWidth={2} fill="url(#vRev)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="glass-card rounded-2xl p-5">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white">Router Status</h3>
                <Router className="h-5 w-5 text-violet-400" />
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between rounded-xl border border-emerald-500/20 bg-emerald-500/5 px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-sm font-medium text-white">Online</span>
                  </div>
                  <span className="text-xl font-bold text-emerald-400">{onlineRouters}</span>
                </div>
                <div className="flex items-center justify-between rounded-xl border border-zinc-500/20 bg-zinc-500/5 px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="h-2.5 w-2.5 rounded-full bg-zinc-500" />
                    <span className="text-sm font-medium text-white">Offline</span>
                  </div>
                  <span className="text-xl font-bold text-zinc-400">{routers.length - onlineRouters}</span>
                </div>
                <div className="rounded-xl border border-white/5 bg-white/[0.02] px-4 py-3">
                  <div className="flex items-center justify-between text-xs text-zinc-400">
                    <span>Total Routers</span>
                    <span className="font-semibold text-white">{routers.length}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="glass-card rounded-2xl p-5">
            <h3 className="mb-4 text-sm font-semibold text-white">Bandwidth Utilization (24h)</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={bandwidthData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="time" tick={{ fill: '#71717a', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#71717a', fontSize: 11 }} axisLine={false} tickLine={false} unit="%" />
                <Tooltip contentStyle={{ background: '#18181b', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', fontSize: '12px' }} />
                <Line type="monotone" dataKey="download" name="Download" stroke="#6366f1" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="upload" name="Upload" stroke="#10b981" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Router Fleet Tab */}
      {activeTab === 'routers' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Router Fleet ({routers.length})</h3>
            <button
              onClick={() => { setGeneratedMac(generateMacAddress()); setGeneratedSecret(generateSecret()); setShowRouterModal(true); }}
              className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-2 text-xs font-medium text-white hover:bg-indigo-500 transition-colors"
            >
              <Plus className="h-3.5 w-3.5" /> Add New Router
            </button>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {routers.map((r) => (
              <div key={r.id} className="glass-card glass-card-hover rounded-2xl p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${r.is_online ? 'bg-emerald-500/15 text-emerald-400' : 'bg-zinc-500/15 text-zinc-500'}`}>
                      <Router className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">{r.nasname}</p>
                      <p className="text-xs text-zinc-500">{r.shortname}</p>
                    </div>
                  </div>
                  <StatusBadge status={r.is_online ? 'online' : 'offline'} />
                </div>
                <div className="mt-4 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-zinc-500">MAC Address</span>
                    <span className="font-mono text-zinc-300">{r.mac_address}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">NAS IP</span>
                    <span className="font-mono text-zinc-300">{r.nas_ip}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Shared Secret</span>
                    <span className="font-mono text-zinc-300">{r.secret}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Last Ping</span>
                    <span className="text-zinc-400">{r.is_online ? timeAgo(r.last_ping) : 'offline'}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Hotspot Plans Tab */}
      {activeTab === 'plans' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Hotspot Plans ({plans.length})</h3>
            <button
              onClick={() => { setEditingPlan(null); setPlanForm({ name: '', price: '', duration_minutes: '60', max_download_kbps: '5120', max_upload_kbps: '2048', max_devices: '1' }); setShowPlanModal(true); }}
              className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-2 text-xs font-medium text-white hover:bg-indigo-500 transition-colors"
            >
              <Plus className="h-3.5 w-3.5" /> Create Plan
            </button>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {plans.map((p) => (
              <div key={p.id} className={`glass-card glass-card-hover rounded-2xl p-5 ${!p.is_active ? 'opacity-50' : ''}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="rounded-lg bg-indigo-500/15 p-2">
                      <Wifi className="h-4 w-4 text-indigo-400" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">{p.name}</p>
                      <p className="text-xs text-zinc-500">{formatDuration(p.duration_minutes)}</p>
                    </div>
                  </div>
                  <span className={`rounded-full border px-2 py-0.5 text-xs ${p.is_active ? 'border-emerald-500/20 bg-emerald-500/10 text-emerald-300' : 'border-zinc-500/20 bg-zinc-500/10 text-zinc-400'}`}>
                    {p.is_active ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <div className="mt-4">
                  <p className="text-2xl font-bold text-white">{formatCurrency(p.price)}</p>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
                    <p className="text-zinc-500">Download</p>
                    <p className="font-medium text-zinc-300">{formatSpeed(p.max_download_kbps)}</p>
                  </div>
                  <div className="rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
                    <p className="text-zinc-500">Upload</p>
                    <p className="font-medium text-zinc-300">{formatSpeed(p.max_upload_kbps)}</p>
                  </div>
                  <div className="rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
                    <p className="text-zinc-500">Devices</p>
                    <p className="font-medium text-zinc-300">{p.max_devices}</p>
                  </div>
                  <div className="rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
                    <p className="text-zinc-500">Duration</p>
                    <p className="font-medium text-zinc-300">{formatDuration(p.duration_minutes)}</p>
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <button onClick={() => openEditPlan(p)} className="flex-1 rounded-lg border border-white/10 px-3 py-2 text-xs font-medium text-zinc-300 hover:bg-white/5 transition-colors">Edit</button>
                  <button onClick={() => togglePlanActive(p)} className="flex-1 rounded-lg border border-white/10 px-3 py-2 text-xs font-medium text-zinc-300 hover:bg-white/5 transition-colors">{p.is_active ? 'Deactivate' : 'Activate'}</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Transactions Tab */}
      {activeTab === 'transactions' && (
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="border-b border-white/10 px-5 py-4">
            <h3 className="text-sm font-semibold text-white">Transaction Ledger ({transactions.length})</h3>
            <p className="text-xs text-zinc-500">All customer payments for {tenant.business_name}</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/10 text-left text-xs text-zinc-500">
                  <th className="px-5 py-3 font-medium">Payment Ref</th>
                  <th className="px-5 py-3 font-medium">Customer</th>
                  <th className="px-5 py-3 font-medium">Package</th>
                  <th className="px-5 py-3 font-medium">Router</th>
                  <th className="px-5 py-3 font-medium">Gross Paid</th>
                  <th className="px-5 py-3 font-medium">Commission</th>
                  <th className="px-5 py-3 font-medium">Net Balance</th>
                  <th className="px-5 py-3 font-medium">Method</th>
                  <th className="px-5 py-3 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((t) => (
                  <tr key={t.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                    <td className="px-5 py-3.5"><span className="font-mono text-xs text-indigo-300">{t.payment_ref}</span></td>
                    <td className="px-5 py-3.5">
                      <p className="text-xs text-zinc-300">{t.customer_phone}</p>
                      <p className="font-mono text-[10px] text-zinc-600">{t.customer_mac}</p>
                    </td>
                    <td className="px-5 py-3.5 text-zinc-300">{planNameById(t.plan_id)}</td>
                    <td className="px-5 py-3.5 text-zinc-400">{nasNameById(t.nas_id)}</td>
                    <td className="px-5 py-3.5 font-medium text-white">{formatCurrency(Number(t.gross_amount))}</td>
                    <td className="px-5 py-3.5 text-rose-400">-{formatCurrency(Number(t.platform_fee))}</td>
                    <td className="px-5 py-3.5 font-medium text-emerald-400">{formatCurrency(Number(t.vendor_net_amount))}</td>
                    <td className="px-5 py-3.5">
                      <span className="rounded-md bg-white/5 px-2 py-1 text-xs capitalize text-zinc-300">{t.payment_method.replace('_', ' ')}</span>
                    </td>
                    <td className="px-5 py-3.5 text-xs text-zinc-500">{formatDateTime(t.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Branding Tab */}
      {activeTab === 'branding' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="glass-card rounded-2xl p-6">
            <h3 className="mb-5 text-sm font-semibold text-white">Portal Branding Customizer</h3>
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-zinc-400">Logo URL</label>
                <div className="flex gap-2">
                  <input
                    value={branding.logo_url}
                    onChange={(e) => setBranding({ ...branding, logo_url: e.target.value })}
                    placeholder="https://example.com/logo.png"
                    className="flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
                  />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-zinc-400">Brand Color</label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={branding.brand_color}
                    onChange={(e) => setBranding({ ...branding, brand_color: e.target.value })}
                    className="h-10 w-16 cursor-pointer rounded-lg border border-white/10 bg-transparent"
                  />
                  <input
                    value={branding.brand_color}
                    onChange={(e) => setBranding({ ...branding, brand_color: e.target.value })}
                    className="flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-mono text-white focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
                  />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-zinc-400">Welcome Headline</label>
                <input
                  value={branding.welcome_headline}
                  onChange={(e) => setBranding({ ...branding, welcome_headline: e.target.value })}
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-zinc-400">Terms of Service</label>
                <textarea
                  value={branding.terms_of_service}
                  onChange={(e) => setBranding({ ...branding, terms_of_service: e.target.value })}
                  rows={4}
                  className="w-full resize-none rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
                />
              </div>
              <button
                onClick={handleSaveBranding}
                disabled={savingBranding}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 px-4 py-3 text-sm font-medium text-white hover:bg-indigo-500 disabled:opacity-50 transition-colors"
              >
                {savingBranding ? <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" /> : <><Palette className="h-4 w-4" /> Save Branding</>}
              </button>
            </div>
          </div>

          <div className="glass-card rounded-2xl p-6">
            <h3 className="mb-5 text-sm font-semibold text-white">Live Portal Preview</h3>
            <div className="rounded-2xl border border-white/10 p-6" style={{ background: `linear-gradient(135deg, ${branding.brand_color}15, #0a0a0b)` }}>
              {branding.logo_url ? (
                <img src={branding.logo_url} alt="Logo" className="mb-4 h-16 w-16 rounded-xl object-cover" />
              ) : (
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl text-2xl font-bold text-white" style={{ background: branding.brand_color }}>
                  {tenant.business_name.charAt(0)}
                </div>
              )}
              <h4 className="text-lg font-bold text-white">{branding.welcome_headline || 'Welcome'}</h4>
              <p className="mt-2 text-sm text-zinc-400">{tenant.business_name}</p>
              <div className="mt-4 space-y-2">
                {plans.filter((p) => p.is_active).slice(0, 3).map((p) => (
                  <div key={p.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-white">{p.name}</p>
                      <p className="text-xs text-zinc-500">{formatDuration(p.duration_minutes)}</p>
                    </div>
                    <span className="font-bold text-white" style={{ color: branding.brand_color }}>{formatCurrency(p.price)}</span>
                  </div>
                ))}
              </div>
              <p className="mt-4 text-xs text-zinc-600">{branding.terms_of_service}</p>
            </div>
          </div>
        </div>
      )}

      {/* Add Router Modal */}
      <Modal
        open={showRouterModal}
        onClose={() => setShowRouterModal(false)}
        title="Add New Router"
        description="Register a new MikroTik NAS to your fleet"
        size="lg"
        footer={
          <>
            <button onClick={() => setShowRouterModal(false)} className="rounded-lg border border-white/10 px-4 py-2 text-sm text-zinc-300 hover:bg-white/5 transition-colors">Cancel</button>
            <button onClick={handleAddRouter} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-500 transition-colors">Add Router</button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-zinc-400">Router Name (NAS Name)</label>
              <input
                value={newRouter.nasname}
                onChange={(e) => setNewRouter({ ...newRouter, nasname: e.target.value })}
                placeholder="MT-CAFE-03"
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-zinc-400">Venue Location</label>
              <input
                value={newRouter.shortname}
                onChange={(e) => setNewRouter({ ...newRouter, shortname: e.target.value })}
                placeholder="Main Cafe"
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-zinc-400">NAS IP Address</label>
              <input
                value={newRouter.nas_ip}
                onChange={(e) => setNewRouter({ ...newRouter, nas_ip: e.target.value })}
                placeholder="10.10.1.3"
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-zinc-400">MAC Address (auto-generated)</label>
              <div className="flex gap-2">
                <input
                  value={generatedMac}
                  onChange={(e) => setGeneratedMac(e.target.value)}
                  className="flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-mono text-white focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
                />
                <button onClick={() => setGeneratedMac(generateMacAddress())} className="rounded-xl border border-white/10 px-3 text-zinc-400 hover:bg-white/5 transition-colors">
                  <Zap className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-zinc-400">RADIUS Shared Secret (auto-generated)</label>
            <div className="flex gap-2">
              <input
                value={generatedSecret}
                onChange={(e) => setGeneratedSecret(e.target.value)}
                className="flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-mono text-white focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
              />
              <button onClick={() => setGeneratedSecret(generateSecret())} className="rounded-xl border border-white/10 px-3 text-zinc-400 hover:bg-white/5 transition-colors">
                <Zap className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-zinc-400">MikroTik Auto-Configuration Script</label>
            <div className="relative">
              <pre className="max-h-48 overflow-auto rounded-xl border border-white/10 bg-black/40 p-4 text-xs font-mono text-emerald-300 leading-relaxed">
                {mikrotikScript(newRouter, generatedMac, generatedSecret)}
              </pre>
              <button
                onClick={() => copyScript(mikrotikScript(newRouter, generatedMac, generatedSecret))}
                className="absolute right-3 top-3 rounded-lg border border-white/10 bg-zinc-900/80 px-2.5 py-1.5 text-xs font-medium text-zinc-300 hover:bg-white/10 transition-colors"
              >
                {copiedScript ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span className="ml-1">{copiedScript ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <p className="mt-2 text-xs text-zinc-600">Paste this script into your MikroTik terminal to auto-configure RADIUS authentication</p>
          </div>
        </div>
      </Modal>

      {/* Plan Modal */}
      <Modal
        open={showPlanModal}
        onClose={() => setShowPlanModal(false)}
        title={editingPlan ? 'Edit Hotspot Plan' : 'Create Hotspot Plan'}
        description="Configure Wi-Fi package details"
        footer={
          <>
            <button onClick={() => setShowPlanModal(false)} className="rounded-lg border border-white/10 px-4 py-2 text-sm text-zinc-300 hover:bg-white/5 transition-colors">Cancel</button>
            <button onClick={handleSavePlan} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-500 transition-colors">{editingPlan ? 'Update Plan' : 'Create Plan'}</button>
          </>
        }
      >
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-zinc-400">Package Name</label>
            <input
              value={planForm.name}
              onChange={(e) => setPlanForm({ ...planForm, name: e.target.value })}
              placeholder="e.g. 1 Hour Speed Boost"
              className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder-zinc-600 focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-zinc-400">Price (USD)</label>
              <input
                type="number" step="0.01" value={planForm.price}
                onChange={(e) => setPlanForm({ ...planForm, price: e.target.value })}
                placeholder="0.50"
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-zinc-400">Duration (minutes)</label>
              <input
                type="number" value={planForm.duration_minutes}
                onChange={(e) => setPlanForm({ ...planForm, duration_minutes: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-zinc-400">Download Speed (Kbps)</label>
              <input
                type="number" value={planForm.max_download_kbps}
                onChange={(e) => setPlanForm({ ...planForm, max_download_kbps: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-zinc-400">Upload Speed (Kbps)</label>
              <input
                type="number" value={planForm.max_upload_kbps}
                onChange={(e) => setPlanForm({ ...planForm, max_upload_kbps: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
              />
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-zinc-400">Simultaneous Devices</label>
            <input
              type="number" min="1" max="10" value={planForm.max_devices}
              onChange={(e) => setPlanForm({ ...planForm, max_devices: e.target.value })}
              className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30"
            />
          </div>
        </div>
      </Modal>
    </div>
  );
}
