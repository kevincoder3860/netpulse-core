export interface Tenant {
  id: string;
  business_name: string;
  email: string;
  platform_commission_pct: number;
  status: 'active' | 'suspended' | 'pending';
  balance: number;
  logo_url: string;
  brand_color: string;
  welcome_headline: string;
  terms_of_service: string;
  created_at: string;
}

export interface Nas {
  id: string;
  tenant_id: string;
  nasname: string;
  shortname: string;
  nas_ip: string;
  mac_address: string;
  secret: string;
  type: string;
  is_online: boolean;
  last_ping: string;
  created_at: string;
}

export interface HotspotPlan {
  id: string;
  tenant_id: string;
  name: string;
  price: number;
  duration_minutes: number;
  max_download_kbps: number;
  max_upload_kbps: number;
  max_devices: number;
  is_active: boolean;
  created_at: string;
}

export interface Transaction {
  id: string;
  tenant_id: string;
  nas_id: string | null;
  plan_id: string | null;
  payment_ref: string;
  customer_phone: string;
  customer_mac: string;
  gross_amount: number;
  platform_fee: number;
  vendor_net_amount: number;
  payment_method: 'mobile_money' | 'card' | 'voucher';
  status: 'completed' | 'pending' | 'failed';
  created_at: string;
}

export interface RadCheck {
  id: string;
  tenant_id: string;
  transaction_id: string | null;
  username: string;
  attribute: string;
  op: string;
  value: string;
  created_at: string;
}

export interface RadReply {
  id: string;
  tenant_id: string;
  transaction_id: string | null;
  username: string;
  attribute: string;
  op: string;
  value: string;
  created_at: string;
}

export interface SystemEvent {
  id: string;
  tenant_id: string | null;
  event_type: 'heartbeat' | 'alert' | 'payment' | 'system' | 'router';
  severity: 'info' | 'warning' | 'error' | 'success';
  message: string;
  created_at: string;
}

export type Role = 'superadmin' | 'vendor' | 'enduser';
